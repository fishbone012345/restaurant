@extends('layout')
@section('content')
    <div class="regtangle7">
    	<a href="">
    		<p id="taiwanText">Taiwan</p>
    		<img src="/image/Taiwan.jpg" id="taiwanImage">
    	</a>
        <a href="">
        	<p id="indonesiaText">Indonesia</p>
        	<img src="/image/indonisa.jpg" id="indonesiaImage">
        </a>
        <a href="">
        	<p id="japanText">Japan</p>
        	<img src="/image/T.jpg" id="japanImage">
        </a>
        <a href="">
        	<p id="koreaText">Korea</p>
        	<img src="/image/T.jpg" id="koreaImage">
        </a>
        <a href="">
        	<p id="singaporeText">Singapore</p>
        	<img src="/image/T.jpg" id="singaporeImage">
        </a>	
        <a href="">
        	<p id="chinaText">China</p>
        	<img src="/image/T.jpg" id="chinaImage">
        </a>	
        	
    </div>
@stop