<?php $__env->startSection('content'); ?>
    <div class="regtangle7">
    	<a href="">
    		<p id="taiwanText">Taiwan</p>
    		<img src="/image/Taiwan.jpg" id="taiwanImage">
    	</a>
        <a href="">
        	<p id="indonesiaText">Indonesia</p>
        	<img src="/image/indonisa.jpg" id="indonesiaImage">
        </a>
        <a href="">
        	<p id="japanText">Japan</p>
        	<img src="/image/T.jpg" id="japanImage">
        </a>
        <a href="">
        	<p id="koreaText">Korea</p>
        	<img src="/image/T.jpg" id="koreaImage">
        </a>
        <a href="">
        	<p id="singaporeText">Singapore</p>
        	<img src="/image/T.jpg" id="singaporeImage">
        </a>	
        <a href="">
        	<p id="chinaText">China</p>
        	<img src="/image/T.jpg" id="chinaImage">
        </a>	
        	
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/chieh-hsianghu/Homestead/restaurant/resources/views/countryList.blade.php ENDPATH**/ ?>