<html>
	<head>
		<link rel=stylesheet type="text/css" href="restaurant.css">
	</head>
    <body>
    	<div id="bar">
    		<img src="/image/restaurant-cutlery-circular-symbol-of-a-spoon-and-a-fork-in-a-circle.png" id="icon">
    		<p id="restaurantInAsia">Restaurant in Asia</p> 
    		<button id="option">Option</button>
    		<a href="" id="register">Register註冊</a>
	        <p id="line">|</p>
	        <a href="" id="login">Login登入</a>
	        <img src="/image/user (1).png" id="userImage">
        </div>
        <div id="regtangle4">
        </div>

        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html><?php /**PATH /Users/chieh-hsianghu/Homestead/restaurant/resources/views/layout.blade.php ENDPATH**/ ?>